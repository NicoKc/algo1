#ifndef LABO_TESTING_SUBSECUENCIAQUESUMA_H
#define LABO_TESTING_SUBSECUENCIAQUESUMA_H

#include <vector>
using namespace std;


bool subSecunciaQueSuma(vector<int> s, int n);

#endif //LABO_TESTING_SUBSECUENCIAQUESUMA_H
