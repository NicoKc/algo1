#include "rotar.h"

vector<int> rotar(vector<int> v, int k){
    vector<int> res;
    return res;
    // Borrar el return dummy y completar

}
