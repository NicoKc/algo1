#ifndef LABO_TESTING_SANDIA_H
#define LABO_TESTING_SANDIA_H

bool sandia(int peso);

#endif //LABO_TESTING_SANDIA_H





