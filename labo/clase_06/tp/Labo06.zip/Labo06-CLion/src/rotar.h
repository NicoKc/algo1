
#ifndef LABO_TESTING_ROTAR_H
#define LABO_TESTING_ROTAR_H

#include <vector>
using namespace std;

vector<int> rotar(vector<int> v, int k);

#endif //LABO_TESTING_ROTAR_H
