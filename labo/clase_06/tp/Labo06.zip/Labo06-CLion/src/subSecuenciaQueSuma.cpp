#include "subSecuenciaQueSuma.h"

bool subSecunciaQueSuma(vector<int> s, int n){
    return false;
    // Borrar el return dummy y completar

}

