
#ifndef LABO_TESTING_AGRUPARANAGRAMAS_H
#define LABO_TESTING_AGRUPARANAGRAMAS_H

#include <vector>
#include "string"
using namespace std;

vector<vector<string> > agruparAnagramas(vector<string> v);
#endif //LABO_TESTING_AGRUPARANAGRAMAS_H
