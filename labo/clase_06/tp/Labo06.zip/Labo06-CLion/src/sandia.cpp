bool sandia(int porciones) {
	return true;
	// Borrar el return dummy y completar
}
