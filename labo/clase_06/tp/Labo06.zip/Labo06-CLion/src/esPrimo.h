#ifndef LABO_TESTING_ESPRIMO_H
#define LABO_TESTING_ESPRIMO_H

bool esPrimo(int n);

#endif //LABO_TESTING_ESPRIMO_H


