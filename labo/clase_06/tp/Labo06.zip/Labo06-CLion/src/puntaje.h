#ifndef LABO_TESTING_PUNTAJE_H
#define LABO_TESTING_PUNTAJE_H

int puntaje(int b);

#endif //LABO_TESTING_PUNTAJE_H


