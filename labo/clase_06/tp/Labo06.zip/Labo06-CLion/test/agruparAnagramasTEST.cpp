#include "../src/agruparAnagramas.h"
#include "../lib/gtest.h"

// Escribir tests aca:
