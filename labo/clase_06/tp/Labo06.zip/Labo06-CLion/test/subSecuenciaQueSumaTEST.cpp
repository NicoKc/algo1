#include "../src/subSecuenciaQueSuma.h"
#include "../lib/gtest.h"

// Escribir tests aca:
