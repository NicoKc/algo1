#include "../src/rotar.h"
#include "../lib/gtest.h"

// Escribir tests aca:
