#include "../src/puntaje.h"
#include "../lib/gtest.h"

// Escribir tests aca:
