#include "lib/gtest.h"
#include "src/solucion.h"
#include <string>


int main(int argc, char **argv) {
        /*
        //DESCOMENTAR CUANDO USEN TESTS
        ::testing::InitGoogleTest(&argc, argv);
        return RUN_ALL_TESTS();
        */
        return 0;
}
