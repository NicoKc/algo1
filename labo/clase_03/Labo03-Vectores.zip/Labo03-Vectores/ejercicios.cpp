#include "ejercicios.h"

bool divide(vector<int> v, int n){
    cout << "Implementame!" << endl;

    return false;
}

int maximo(vector<int> v){
    cout << "Implementame!" << endl;

    return 0;
}

bool pertenece(int elem, vector<int> v){
    cout << "Implementame!" << endl;

    return false;
}

void mostrarVector(vector<int> v){
    cout << "Implementame!" << endl;

}

void sinImpares(vector<int>& v){
    cout << "Implementame!" << endl;
}

vector<int> limpiarDuplicados(vector<int> v){
    cout << "Implementame!" << endl;

    vector<int> res;
    return res;
}

vector<int> rotar(vector<int> v, int k){
    cout << "Implementame!" << endl;

    vector<int> res;
    return res;
}

vector<int> reverso(vector<int> v){
    cout << "Implementame!" << endl;

    vector<int> res;
    return res;
}


vector<int> reversoRec(vector<int> v){
    cout << "Implementame!" << endl;

    vector<int> res;
    return res;
}


vector<int> factoresPrimos(int n){
    cout << "Implementame!" << endl;

    vector<int> res;
    return res;
}


bool estaOrdenado(vector<int> v){
    cout << "Implementame!" << endl;

    return false;
}

void negar(vector<bool>& booleanos){
    cout << "Implementame!" << endl;
}

vector<pair<int, int> > cantidadApariciones(vector<int> v){
    cout << "Implementame!" << endl;

    vector<pair<int, int> > res;
    return res;
}

void palindromos(string rutaArchivoIn, string rutaArchivoOut)
{
    cout << "Implementame!" << endl;
}

void promedios(string rutaArchivoIn1, string rutaArchivoIn2, string rutaArchivoOut)
{
    cout << "Implementame!" << endl;
}

void cantidadApariciones(string rutaArchivoIn, string rutaArchivoOut)
{
    cout << "Implementame!" << endl;
}

void estadisticas(string rutaArchivo)
{
    cout << "Implementame!" << endl;
}

void interseccion()
{
    cout << "Implementame!" << endl;
}

